//
//  MGSearchCell.h
//  MGDemo
//
//  Created by ming on 16/6/21.
//  Copyright © 2016年 ming. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MGSearchCell : UITableViewCell

@end
