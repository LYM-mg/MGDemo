//
//  MGSectionModel.m
//  turnView
//
//  Created by ming on 16/6/13.
//  Copyright © 2016年 ming. All rights reserved.

///  每个section对应的模型

#import "MGSectionModel.h"

@implementation MGSectionModel

@end
