//
//  MGCellModel.m
//  turnView
//
//  Created by ming on 16/6/13.
//  Copyright © 2016年 ming. All rights reserved.

///  每个cell对应的模型

#import "MGCellModel.h"

@implementation MGCellModel

@end
