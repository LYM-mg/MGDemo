//
//  XJLLiveTaskHeaderView.h
//  SwiftLive
//
//  Created by Zhaimi on 2018/1/19.
//  Copyright © 2018年 DotC_United. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XJLLiveTaskHeaderView : UITableViewHeaderFooterView

@end
