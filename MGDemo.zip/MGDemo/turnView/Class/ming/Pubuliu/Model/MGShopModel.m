//
//  MGShopModel.m
//  MGPuBuLiuDemo
//
//  Created by ming on 16/6/9.
//  Copyright © 2016年 ming. All rights reserved.
//

#import "MGShopModel.h"

@implementation MGShopModel

@end
