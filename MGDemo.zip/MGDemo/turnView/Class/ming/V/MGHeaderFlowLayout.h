//
//  MGHeaderFlowLayout.h
//  MGDemo
//
//  Created by ming on 16/7/9.
//  Copyright © 2016年 ming. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MGHeaderFlowLayout : UICollectionViewFlowLayout
//默认为64.0, default is 64.0
@property (nonatomic, assign) CGFloat navHeight;
@end
