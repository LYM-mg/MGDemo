//
//  MGBodyCell.h
//  MGDemo
//
//  Created by ming on 16/7/9.
//  Copyright © 2016年 ming. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MGBodyModel;

@interface MGBodyCell : UICollectionViewCell

/** 模型属性  */
@property (nonatomic, strong) MGBodyModel *bodyModel;

@end
