//
//  MGAlertController.h
//  MGDemo
//
//  Created by newunion on 2018/1/17.
//  Copyright © 2018年 ming. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MGAlertController : UIAlertController

@end
