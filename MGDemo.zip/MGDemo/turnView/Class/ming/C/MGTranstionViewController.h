//
//  MGTranstionViewController.h
//  MGDemo
//
//  Created by newunion on 2018/1/16.
//  Copyright © 2018年 ming. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MGTranstionViewController : UIViewController

@end
