//
//  MGHeaderCollectionVC.h
//  MGDemo
//
//  Created by ming on 16/7/9.
//  Copyright © 2016年 ming. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MGHeaderCollectionVC : UIViewController

@end
