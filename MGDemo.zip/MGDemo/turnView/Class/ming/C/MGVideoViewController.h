//
//  MGVideoViewController.h
//  turnView
//
//  Created by ming on 16/6/14.
//  Copyright © 2016年 ming. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MGVideoViewController : UIViewController

@end
