//
//  UIColor+LYMExtension.h
//  ScrollDemo
//
//  Created by newunion on 2018/4/11.
//  Copyright © 2018年 newunion. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (LYMExtension)
+ (UIColor *)colorWithHexString:(NSString *)color;
@end
