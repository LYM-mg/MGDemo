//
//  MGApplication.h
//  MGDemo
//
//  Created by i-Techsys.com on 2017/9/26.
//  Copyright © 2017年 ming. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MGApplication : NSObject
@property (nonatomic,copy) NSString *appId;
@property (nonatomic,copy) NSString *appVersion;
@end
