//
//  MGHeTableViewController.h
//  MGDemo
//
//  Created by i-Techsys.com on 2017/8/16.
//  Copyright © 2017年 ming. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MGHeTableViewController : UIViewController

@end
