//
//  MGAnimationPushVC.h
//  MGDemo
//
//  Created by ming on 16/7/8.
//  Copyright © 2016年 ming. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MGAnimationPushVC : UIViewController
/** image */
@property (nonatomic,strong) UIImage *myImage;
/** backImageView */
@property (nonatomic,weak) UIImageView *backImageView;
@end
