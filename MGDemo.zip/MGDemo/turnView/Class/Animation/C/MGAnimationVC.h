//
//  MGAnimationVC.h
//  MGDemo
//
//  Created by ming on 16/7/8.
//  Copyright © 2016年 ming. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MGAnimationVC : UIViewController
/** 当前按钮 */
@property(strong,nonatomic)UIButton *button;
@end
