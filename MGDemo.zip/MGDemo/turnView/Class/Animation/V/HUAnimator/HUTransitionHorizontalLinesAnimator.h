//
//  HUTransitionHorizontallLinesAnimator.h
//  EasyBeats
//
//  Created by Christian Inkster on 16/09/13.
//
//

#import <Foundation/Foundation.h>
#import "HUTransitionAnimator.h"

@interface HUTransitionHorizontalLinesAnimator : HUTransitionAnimator

@end
