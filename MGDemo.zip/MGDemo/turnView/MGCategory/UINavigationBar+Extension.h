//
//  UINavigationBar+Extension.h
//  MGDemo
//
//  Created by i-Techsys.com on 2017/7/29.
//  Copyright © 2017年 ming. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UINavigationBar (Extension)
//@property (nonatomic,assign) BOOL mg_hideStatusBarBackgroungView;
@end
